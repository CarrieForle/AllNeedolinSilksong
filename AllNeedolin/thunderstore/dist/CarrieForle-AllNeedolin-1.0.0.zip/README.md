# AllNeedolin

Give you every needolin paragraph in one go.